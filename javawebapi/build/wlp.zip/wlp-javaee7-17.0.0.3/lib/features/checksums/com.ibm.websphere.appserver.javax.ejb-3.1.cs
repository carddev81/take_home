#Fri Oct 13 05:02:16 BST 2017
lib/features/com.ibm.websphere.appserver.javax.ejb-3.1.mf=ba9866aef91f91ac8e0e2bc90197b702
dev/api/spec/com.ibm.websphere.javaee.ejb.3.1_1.0.18.jar=ce03974723cbecac343f7d004fb3f498
