#Fri Oct 13 05:02:16 BST 2017
dev/api/spec/com.ibm.websphere.javaee.connector.1.7_1.0.18.jar=d2e6f994e2a851a46d382fd76d1ce1b6
lib/features/com.ibm.websphere.appserver.javax.connector-1.7.mf=a71c1448d30ccc07ff2e42a28514ef2e
