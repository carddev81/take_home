#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.ejbcontainer.jpa.nls_1.0.18.jar=d10f03511d55893c83408704a0f43e6c
lib/features/com.ibm.ws.ejbcontainer.jpa.nls-1.0.mf=2387ce69f0c5795034efdd19b261e958
