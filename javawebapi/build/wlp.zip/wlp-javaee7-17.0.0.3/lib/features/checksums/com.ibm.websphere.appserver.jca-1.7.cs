#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.jca-1.7.mf=1451229bdd06e45a8c54dbc95c4fb2ca
lib/com.ibm.ws.app.manager.rar_1.0.18.jar=d06ebd1d66403da5a236b2b323f4fb9b
lib/com.ibm.ws.jca.1.7_1.0.18.jar=e6365c0924a81849ba4983c9db4b3aa9
