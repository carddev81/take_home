#Fri Oct 13 05:02:16 BST 2017
lib/features/com.ibm.websphere.appserver.microProfile-1.0.mf=36f3a4e08a6a676257a0f3b8858f754c
lib/com.ibm.ws.require.java8_1.0.18.jar=cd73f2462b5da84480b92521f6c35ce2
