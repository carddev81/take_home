#Fri Oct 13 05:02:16 BST 2017
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.18.jar=db197b9a7fd2b80310858370539b16a3
lib/features/com.ibm.websphere.appserver.javax.jsp-2.3.mf=d03397d99a427e5ff81e0db0aa6d1bce
