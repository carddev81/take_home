#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.jdbcJ2eeManagement-1.0.mf=bda5a2fb5ddc0c1169f2791cd8d902d3
lib/com.ibm.ws.jdbc.management.j2ee_1.0.18.jar=b210d33a975f3966430162c9e4555a25
