#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.ws.jndi.nls-1.0.mf=06a0396167e62d23358c5a4242bb1f07
lib/com.ibm.ws.jndi.nls_1.0.18.jar=fa6bc03fdac83131d2b025d2069b0bb2
