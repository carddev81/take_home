#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.transport.iiop.server_1.0.18.jar=2e05bf9e155bde87d98785ba12a88a0f
lib/features/com.ibm.websphere.appserver.iioptransport-1.0.mf=420342c4ff4613278f554b6a1ff57f8b
