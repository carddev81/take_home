#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.autoRestHandlerApiDiscovery-1.0.mf=16f69c6710118f3c6427f2a6a318a4a2
dev/spi/ibm/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0.18.jar=9441f36e2749d0856c029a4f32619cd9
lib/com.ibm.websphere.rest.api.discovery_1.0.18.jar=f225eb9f78986ca0df144b0fc442ee5a
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0-javadoc.zip=dc78448c94ec2d8f875d45e1d3170de4
