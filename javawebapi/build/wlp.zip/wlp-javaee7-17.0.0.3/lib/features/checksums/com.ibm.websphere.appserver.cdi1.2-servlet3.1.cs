#Fri Oct 13 05:02:15 BST 2017
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.18.jar=db197b9a7fd2b80310858370539b16a3
lib/com.ibm.ws.cdi.1.2.web_1.0.18.jar=d83b5554402092b142eb849caeee4d0c
lib/features/com.ibm.websphere.appserver.cdi1.2-servlet3.1.mf=4e51e8078674113e942b23922e9bf237
