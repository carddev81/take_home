#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.jmsJ2eeManagement-1.0.mf=c07b3b9e090a96687d16f0a0445c5244
lib/com.ibm.ws.messaging.jms.j2ee.mbeans_1.0.18.jar=ee8ea1703efba46cf84a3f0befd49709
