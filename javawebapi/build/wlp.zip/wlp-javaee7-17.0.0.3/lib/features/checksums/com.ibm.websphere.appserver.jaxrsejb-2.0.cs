#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.jaxrsejb-2.0.mf=2b9f65641b8609797cc7cfd989a7c25b
lib/com.ibm.ws.jaxrs.2.0.ejb_1.0.18.jar=eb0a5259074a0dd7607b95541ccfb20d
