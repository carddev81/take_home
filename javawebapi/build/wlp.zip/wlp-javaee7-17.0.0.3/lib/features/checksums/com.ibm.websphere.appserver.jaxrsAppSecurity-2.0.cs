#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.jaxrs.2.0.security_1.0.18.jar=e891a2355acdb9ba22b43ed6f900f9c3
lib/features/com.ibm.websphere.appserver.jaxrsAppSecurity-2.0.mf=fa304fd24d7b2c04aab50bf5efcd8678
