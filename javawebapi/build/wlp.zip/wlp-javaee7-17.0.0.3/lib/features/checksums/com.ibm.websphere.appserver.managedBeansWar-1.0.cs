#Fri Oct 13 05:02:16 BST 2017
lib/features/com.ibm.websphere.appserver.managedBeansWar-1.0.mf=9224da73114ec5c174556598abd3752a
lib/com.ibm.ws.ejbcontainer.war_1.0.18.jar=ca614ffa1ff758b619958864867a148a
