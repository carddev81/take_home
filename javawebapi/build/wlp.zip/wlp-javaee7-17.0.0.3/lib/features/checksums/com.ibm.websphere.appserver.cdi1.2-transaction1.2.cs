#Fri Oct 13 05:02:15 BST 2017
lib/com.ibm.ws.cdi.1.2.transaction_1.0.18.jar=0a985a84e4a73f02f590defc4b85c42a
lib/features/com.ibm.websphere.appserver.cdi1.2-transaction1.2.mf=60de251df0d7c78c26169bf6c041b469
