#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.mdb-3.2.mf=2cadf64a17fadb9a3bf0e9a616a54c7c
lib/com.ibm.ws.ejbcontainer.v32_1.0.18.jar=d36b07b4b8267bc0f11d3e08e15eaa86
lib/com.ibm.ws.ejbcontainer.mdb_1.0.18.jar=0427d7b1996fe163faf6518633837002
