#Fri Oct 13 05:02:15 BST 2017
lib/com.ibm.ws.cdi.1.2.ejb_1.0.18.jar=bf80514cbb9306bc5ac6ee6ef64f21bd
lib/features/com.ibm.websphere.appserver.cdi1.2-ejb3.2.mf=bc50bc040756e20307de4def8322e9c3
