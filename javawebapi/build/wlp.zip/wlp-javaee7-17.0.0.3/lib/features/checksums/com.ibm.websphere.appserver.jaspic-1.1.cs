#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.security.jaspic.1.1_1.0.18.jar=1ee0f757dad93eae1b368b885a00d600
dev/spi/ibm/com.ibm.websphere.appserver.spi.jaspic_1.1.18.jar=cf0b9a23e60d87db237aea8df42cb0bb
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.jaspic_1.1-javadoc.zip=a54fe4033520b3b93a31b45090ffcd16
dev/api/spec/com.ibm.websphere.javaee.jaspic.1.1_1.0.18.jar=f0e4ffe2f3913bb66be040f487505a0d
lib/features/com.ibm.websphere.appserver.jaspic-1.1.mf=4904dbb127b3b517905751be9b091271
