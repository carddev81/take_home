#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.jndiJ2eeManagement-1.0.mf=8ab042540689541d80650a94baeac083
lib/com.ibm.ws.jndi.management.j2ee_1.0.18.jar=50dcd4fb860671f760ecf4e92f0d25e2
