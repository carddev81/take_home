#Fri Oct 13 05:02:16 BST 2017
lib/features/com.ibm.ws.jaxrs.2.0.common.nls-1.0.mf=69d58da8922beac500f1fa1e6ae69292
lib/com.ibm.ws.jaxrs.2.0.common.nls_1.0.18.jar=3d6902a6245e1ab76e4d05b738440659
