#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.internal.jca-1.6.mf=89027bd6617c1d426eb45e7158d4125f
lib/com.ibm.ws.jca.utils_1.0.18.jar=1364d90767862b6d41bb4905ab6cc05b
lib/com.ibm.ws.jca.feature_1.0.18.jar=3ab11f4ac615847c6522bf26ef64c81e
lib/com.ibm.ws.jca_1.0.18.jar=e46e19c0b3ab8e0f2a6f57f6551b34ed
