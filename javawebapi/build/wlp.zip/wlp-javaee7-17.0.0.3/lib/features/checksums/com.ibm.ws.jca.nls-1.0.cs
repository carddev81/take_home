#Fri Oct 13 05:02:16 BST 2017
lib/features/com.ibm.ws.jca.nls-1.0.mf=5cedc31d44acae2b5ae563c8f31fa6a6
lib/com.ibm.ws.jca.nls_1.0.18.jar=824e59b117999e3446054998d2775e36
