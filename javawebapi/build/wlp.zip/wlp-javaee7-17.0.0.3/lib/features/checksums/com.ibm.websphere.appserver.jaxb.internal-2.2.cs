#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.jaxb.internal-2.2.mf=65b91aff3aa27dabbeebd729c9ad4b51
lib/com.ibm.ws.xlxp.1.5.3_1.0.18.jar=f7a80119b05d23c8d3a51447959f4c6a
