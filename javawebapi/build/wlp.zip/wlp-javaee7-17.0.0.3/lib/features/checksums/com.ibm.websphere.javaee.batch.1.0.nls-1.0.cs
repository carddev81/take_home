#Fri Oct 13 05:02:15 BST 2017
lib/com.ibm.websphere.javaee.batch.1.0.nls_1.0.18.jar=dbe11e3adeccc9da27b8903db2bca6d7
lib/features/com.ibm.websphere.javaee.batch.1.0.nls-1.0.mf=62af18ee1ed8f168422efbcc6ee8cca0
