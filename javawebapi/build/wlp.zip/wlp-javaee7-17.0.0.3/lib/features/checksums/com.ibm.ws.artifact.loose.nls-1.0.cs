#Fri Oct 13 05:02:15 BST 2017
lib/com.ibm.ws.artifact.loose.nls_1.0.18.jar=f541992f7700d37ce52cd49a051a75d2
lib/features/com.ibm.ws.artifact.loose.nls-1.0.mf=fcb8ec368299415c2cea877226181817
