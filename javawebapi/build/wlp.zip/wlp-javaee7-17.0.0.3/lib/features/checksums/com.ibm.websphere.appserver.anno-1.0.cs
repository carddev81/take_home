#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.anno-1.0.mf=2943facf96b3795af80929a48af2712a
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.anno_1.0-javadoc.zip=4772257a87e82915edaf5a8833a40cbf
lib/com.ibm.ws.anno_1.0.18.jar=203bb9b097241a060643c1185f619b32
dev/spi/ibm/com.ibm.websphere.appserver.spi.anno_1.0.18.jar=50b40e7485654c12b4637c38b220cce0
