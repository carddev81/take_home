#Fri Oct 13 05:02:15 BST 2017
lib/com.ibm.ws.jca.inbound.security_1.0.18.jar=131963f0459bf657bc3878f773c533d5
dev/api/spec/com.ibm.websphere.javaee.jaspic.1.1_1.0.18.jar=f0e4ffe2f3913bb66be040f487505a0d
lib/features/com.ibm.websphere.appserver.jcaInboundSecurity-1.0.mf=a21fa2acf32f04f7ce8b5dca946db7fe
