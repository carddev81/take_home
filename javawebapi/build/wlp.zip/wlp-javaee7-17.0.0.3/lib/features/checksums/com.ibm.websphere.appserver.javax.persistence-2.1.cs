#Fri Oct 13 05:02:16 BST 2017
dev/api/spec/com.ibm.websphere.javaee.persistence.2.1_1.0.18.jar=f9aba710289f9b2c6d3c9387dfaf2b93
lib/features/com.ibm.websphere.appserver.javax.persistence-2.1.mf=0dcbce3f4012e7b885a3479061543fc1
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.18.jar=d686bc035ee02d89352a29513ea9bcbf
