#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.javaee.platform.defaultresource_1.0.18.jar=262f45577fe085a54405adb5adf01226
lib/com.ibm.ws.resource_1.0.18.jar=900f5bac9b4aa46f2c42876ba1bc8d4f
dev/api/spec/com.ibm.websphere.javaee.concurrent.1.0_1.0.18.jar=7dd34ab1b0507a742ec5ee16ed616c1e
lib/com.ibm.ws.concurrent.persistent_1.0.18.jar=f7cc3b7843b7a44e7c88ed851f3b96ba
lib/features/com.ibm.websphere.appserver.persistentExecutorSubset-1.0.mf=0966c2423980e5c51fa645b8f06d21d9
