#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.jbatch.container.nls-1.0.mf=9bd0356defcba4694e0ae1683bade578
lib/com.ibm.jbatch.container.nls_1.0.18.jar=209a3c107b95272f5fb3dd9b256ae4cc
