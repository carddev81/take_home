#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.jca.resourcedefinition.jms-2.0.mf=fc3ac544bd34fd734cc4fa9ae186c2cf
lib/com.ibm.ws.jca.resourcedefinition.jms.2.0_1.0.18.jar=d41f29f8b1b52d007e9d1950343ce77b
