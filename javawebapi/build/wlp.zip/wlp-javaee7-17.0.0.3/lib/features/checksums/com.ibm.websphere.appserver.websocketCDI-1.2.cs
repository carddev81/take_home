#Fri Oct 13 05:02:15 BST 2017
lib/com.ibm.ws.wsoc.cdi.weld_1.0.18.jar=1b0898669072487de7379fa24af1a6ef
lib/features/com.ibm.websphere.appserver.websocketCDI-1.2.mf=de45d3bb72fb71dd458c3d8f4775434a
