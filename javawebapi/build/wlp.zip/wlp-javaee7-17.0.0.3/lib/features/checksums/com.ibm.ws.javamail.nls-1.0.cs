#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.ws.javamail.nls-1.0.mf=7989a77a5322e758234f66393db07488
lib/com.ibm.ws.javamail.nls_1.0.18.jar=c98262b1842c03cd1f04ab2476edc27b
