#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.1.mf=ee405468768f632fc32e048f7d3eb7f8
lib/com.ibm.ws.javaee.persistence.2.1_1.0.18.jar=ebb62e85129859b3c2cb9dd8acc07484
