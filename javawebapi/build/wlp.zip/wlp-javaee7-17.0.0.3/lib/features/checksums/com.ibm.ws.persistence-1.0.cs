#Fri Oct 13 05:02:16 BST 2017
dev/api/ibm/com.ibm.websphere.appserver.api.persistence_1.0.18.jar=878d042511d216e5eddc16c3ed40a3cb
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.persistence_1.0-javadoc.zip=ea050f0e4844c95127c51c5e378cfb58
lib/com.ibm.ws.persistence_1.0.18.jar=4da85ce5dea9319ecc12d9a3589782d9
lib/features/com.ibm.ws.persistence-1.0.mf=9330b996f7581a535e5db18951995e1c
bin/tools/ws-generateddlutil.jar=52a921e3909a700998cea33e28576f22
lib/com.ibm.ws.persistence.mbean_1.0.18.jar=89e8fd573f868bdfc5471ea4d6ff6dff
lib/com.ibm.ws.persistence.utility_1.0.18.jar=f5b77438c97fcac5584a2da26ded7a4d
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.18.jar=94e95b77ed725786acefa35c28f7dcb2
