#Fri Oct 13 05:02:15 BST 2017
lib/com.ibm.ws.persistence.nls_1.0.18.jar=de9c24a974a1e61fa5cfa01a6c3d5171
lib/features/com.ibm.ws.persistence.nls-1.0.mf=ffc59b94b1f5db7be61debc4b1136447
