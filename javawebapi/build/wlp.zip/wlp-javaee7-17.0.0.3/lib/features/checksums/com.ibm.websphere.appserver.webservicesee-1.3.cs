#Fri Oct 13 05:02:15 BST 2017
lib/com.ibm.ws.webservices.javaee.common_1.0.18.jar=817e562ec23c14118ced181280d53525
dev/api/spec/com.ibm.websphere.javaee.jaxws.2.2_1.0.18.jar=0f222d806ea7d09ecfef32d3c4fa9d92
lib/features/com.ibm.websphere.appserver.webservicesee-1.3.mf=f024f79ca1d7c16f29796a1e4256fb76
lib/com.ibm.ws.javaee.ddmodel.ws_1.0.18.jar=6333bf570174b1de220ecb3e5d7ff14f
