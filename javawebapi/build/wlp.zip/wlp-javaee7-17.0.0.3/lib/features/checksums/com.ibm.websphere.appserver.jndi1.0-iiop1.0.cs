#Fri Oct 13 05:02:16 BST 2017
lib/features/com.ibm.websphere.appserver.jndi1.0-iiop1.0.mf=602ca0ca01d8c8c958eb163c40d5fffd
lib/com.ibm.ws.jndi.iiop_1.0.18.jar=8d6093ceccee31cdac88a88833c82973
