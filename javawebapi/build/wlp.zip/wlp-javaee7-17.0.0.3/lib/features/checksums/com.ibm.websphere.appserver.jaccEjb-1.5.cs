#Fri Oct 13 05:02:15 BST 2017
dev/api/spec/com.ibm.websphere.javaee.jacc.1.5_1.0.18.jar=1faf8f938811cc7da0590d10641df0e5
lib/features/com.ibm.websphere.appserver.jaccEjb-1.5.mf=3e6e92c1789223ca776b454d42ce230a
lib/com.ibm.ws.security.authorization.jacc.ejb_1.0.18.jar=d0996a9ce2f3e9272d1401b0d108e370
