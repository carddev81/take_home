#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.ws.transport.http.nls-1.0.mf=b26868bed8f768072851e0e4799ab9ba
lib/com.ibm.ws.transport.http.nls_1.0.18.jar=7fc20baa43c1be9d6abe7a36498f7dbe
