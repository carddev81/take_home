#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.jndi_1.0.18.jar=1e404a0239c9303baf5d518ae7440ac3
lib/com.ibm.ws.org.apache.aries.jndi.core_1.1.18.jar=886ff5a3d8f2405269cc17e439a19f6a
lib/features/com.ibm.websphere.appserver.jndi-1.0.mf=9ad61f43ad86aeb41d6f925c2a9ad281
lib/com.ibm.ws.org.apache.aries.jndi.api_1.1.18.jar=52f52ec4359f791f4869b1d3b687e722
lib/com.ibm.ws.jndi.url.contexts_1.0.18.jar=7b371a959cfaad67ba202a9494e02d89
