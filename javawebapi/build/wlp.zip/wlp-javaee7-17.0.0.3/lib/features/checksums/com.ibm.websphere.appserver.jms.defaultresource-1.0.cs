#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.messaging.jms.defaultresource_1.0.18.jar=f791557fec14346293a496d017825e19
lib/features/com.ibm.websphere.appserver.jms.defaultresource-1.0.mf=942072df516d4bc441a56ce88fe06764
