#Fri Oct 13 05:02:15 BST 2017
lib/com.ibm.ws.cdi.1.2.client_1.0.18.jar=ea978aad954bb970c1d452d55213c74b
lib/features/com.ibm.websphere.appserver.cdi1.2-appSecurityClient1.0.mf=d403d206eb8b4e209661679df2be6f91
