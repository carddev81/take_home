#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.ws.jca.cm.nls-1.0.mf=beafc359368a499f9038e1e60f82c7d9
lib/com.ibm.ws.jca.cm.nls_1.0.18.jar=6291a47b6fe8eea6515545a3f104571b
