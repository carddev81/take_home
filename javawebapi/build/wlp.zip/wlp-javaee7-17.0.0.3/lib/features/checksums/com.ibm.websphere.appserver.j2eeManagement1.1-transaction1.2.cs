#Fri Oct 13 05:02:16 BST 2017
lib/features/com.ibm.websphere.appserver.j2eeManagement1.1-transaction1.2.mf=5818d8a0ab9ea4775322bea6bd15e570
lib/com.ibm.ws.transaction.management_1.0.18.jar=eba86919dd4ac84da8a4d67ee96bfa85
