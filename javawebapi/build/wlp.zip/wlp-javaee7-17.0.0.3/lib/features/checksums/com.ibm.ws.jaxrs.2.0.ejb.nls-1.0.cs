#Fri Oct 13 05:02:16 BST 2017
lib/features/com.ibm.ws.jaxrs.2.0.ejb.nls-1.0.mf=9f2eb971b11d55264ec721952638fa13
lib/com.ibm.ws.jaxrs.2.0.ejb.nls_1.0.18.jar=7588faea09bfe7b354cb18eba7770f03
