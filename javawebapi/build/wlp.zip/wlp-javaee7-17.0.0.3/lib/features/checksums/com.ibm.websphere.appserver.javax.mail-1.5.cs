#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.javax.mail-1.5.mf=cbda9e9e622e1ac118231f9f15d009c5
lib/com.ibm.ws.com.sun.mail.javax.mail.1.5_1.5.18.jar=ddf4dfde965d54ca56b58f09075c9cce
