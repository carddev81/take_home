#Fri Oct 13 05:02:16 BST 2017
lib/features/com.ibm.websphere.appserver.javaMailJ2eeManagement-1.0.mf=1eee3513abbd128b0652247e9511ea18
lib/com.ibm.ws.javamail.management.j2ee_1.0.18.jar=762999c79bab9476b7586e11f5f1eec2
