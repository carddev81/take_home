#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.jca.management.j2ee_1.0.18.jar=3a4d610c6f349a8d38d2b7ab7edb19f6
lib/features/com.ibm.websphere.appserver.jcaJ2eeManagement-1.0.mf=93e36a64c97ce1af7d1bc0d032050794
