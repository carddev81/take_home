#Fri Oct 13 05:02:16 BST 2017
lib/features/com.ibm.websphere.appserver.javaMail-1.5.mf=a0bc2921670214762d12fa4c9ff0e2d7
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.mail_1.0.18.jar=df062e5ba214679d6e7c19b61517f373
lib/com.ibm.ws.javamail_1.5.18.jar=4bf8f4a749d0ecfc687650085d12aa2e
dev/api/spec/com.ibm.websphere.javaee.mail.1.5_1.0.18.jar=c26ad195ca41ae4d9f4e769120fe7f4c
