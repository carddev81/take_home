#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.jaxwscdi-2.2.mf=d76440064a85edad1f304b5750b83606
lib/com.ibm.ws.jaxws.cdi_1.0.18.jar=e1d3f2afc7238cba0d60bd90447bfde1
