#Fri Oct 13 05:02:15 BST 2017
lib/com.ibm.ws.beanvalidation.v11.cdi_1.0.18.jar=0634a8dfac14e901d7372b8afbfc5d41
lib/features/com.ibm.websphere.appserver.beanValidationCDI-1.0.mf=2a42370c5ab2c5fcd18a4cfbc4d69fca
