#Fri Oct 13 05:02:16 BST 2017
dev/api/spec/com.ibm.websphere.javaee.jsf.2.2_1.0.18.jar=b41e69e966ca9ed23ce65e3427b6f4ac
lib/features/com.ibm.websphere.appserver.javax.jsf-2.2.mf=f9f82752c4c24558c1a5fd26ebe8eeb8
