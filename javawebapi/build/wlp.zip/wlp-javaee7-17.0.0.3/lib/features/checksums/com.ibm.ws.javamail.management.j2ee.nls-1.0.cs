#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.javamail.management.j2ee.nls_1.0.18.jar=482fb3cd2a5d27b97f0eaced1f231be6
lib/features/com.ibm.ws.javamail.management.j2ee.nls-1.0.mf=88d5b542fd574247cd31f7e968f0518a
