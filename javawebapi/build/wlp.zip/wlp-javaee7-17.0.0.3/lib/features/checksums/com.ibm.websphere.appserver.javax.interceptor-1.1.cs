#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.1.mf=a3bc91709264dee081411d7ff21e2ab8
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.1_1.0.18.jar=b40a0ab9e32f794327b7b0285af05a0a
