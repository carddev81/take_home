#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.cdi.1.2.jms_1.0.18.jar=5606373e8a2248a75b470ae6425f7ca8
lib/features/com.ibm.websphere.appserver.cdi1.2-jms-2.0.mf=a5ddf5229210898db42293afad2a2e26
