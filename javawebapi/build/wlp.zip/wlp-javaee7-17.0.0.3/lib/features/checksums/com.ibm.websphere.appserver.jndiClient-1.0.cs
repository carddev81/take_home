#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.jndi.remote.client_1.0.18.jar=9dab29c40ac038cf2e8cd4a553a223be
lib/features/com.ibm.websphere.appserver.jndiClient-1.0.mf=63f6b598f5e1c6837c05bf65d636b0b4
