#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.ws.messaging.comms.server.nls-1.0.mf=bb7531b55f84fb609bf7c2eadfd42369
lib/com.ibm.ws.messaging.comms.server.nls_1.0.18.jar=df5ef9e3d6478c7ddf70df1b15ac3425
