#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.jbatch.cdi_1.0.18.jar=9d7ce6f0c51ca5df32e0f2cdeeadacf2
lib/features/com.ibm.websphere.appserver.cdi-1.2-batch-1.0.mf=9649149528e0e13f4d6f3e4d9f4ea60c
