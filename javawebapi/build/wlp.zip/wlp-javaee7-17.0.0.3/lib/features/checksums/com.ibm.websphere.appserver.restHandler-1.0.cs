#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.restHandler-1.0.mf=effa33288a0c52c1de3bf9e58cd09029
lib/com.ibm.ws.rest.handler_1.0.18.jar=73715f6ef57220b6498a989cae7a35fd
dev/spi/ibm/com.ibm.websphere.appserver.spi.restHandler_2.0.18.jar=45cb31ac32b910b68cab22854b4e68c2
lib/com.ibm.websphere.jsonsupport_1.0.18.jar=aeb2165c584c92b180852b761256cd95
lib/com.ibm.websphere.rest.handler_1.0.18.jar=787cab90bcac0c306b7b7c1a5bf0c7d5
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restHandler_2.0-javadoc.zip=50f2e51994d56bd940cb13a5ad7e2b19
lib/com.ibm.ws.org.joda.time.1.6.2_1.0.18.jar=bb59282580b28f2c2cedce5374b2fd0f
