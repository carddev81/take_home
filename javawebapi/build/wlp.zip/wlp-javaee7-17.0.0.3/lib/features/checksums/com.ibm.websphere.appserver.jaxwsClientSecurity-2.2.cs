#Fri Oct 13 05:02:16 BST 2017
lib/features/com.ibm.websphere.appserver.jaxwsClientSecurity-2.2.mf=2ff7fe4f718b1789c9ff34816849a674
lib/com.ibm.ws.jaxws.clientcontainer.security_1.0.18.jar=cb6360e912732134c816270184e4072d
