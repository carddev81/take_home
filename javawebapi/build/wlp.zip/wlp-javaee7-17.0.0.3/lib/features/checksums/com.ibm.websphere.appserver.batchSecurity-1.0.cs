#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.batchSecurity-1.0.mf=314dcbbc05d70075240735b19e88c516
lib/com.ibm.ws.jbatch.security_1.0.18.jar=1edef7f244c4e592cfa6bf81ec8e49a9
