#Fri Oct 13 05:02:16 BST 2017
dev/api/spec/com.ibm.websphere.javaee.cdi.1.2_1.2.18.jar=b39ed503e3071201648334cb281acf52
lib/features/com.ibm.websphere.appserver.javax.cdi-1.2.mf=2b8ee05e6c717e10ae05a888be26e4f3
