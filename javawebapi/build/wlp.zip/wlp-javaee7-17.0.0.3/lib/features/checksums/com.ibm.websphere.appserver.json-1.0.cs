#Fri Oct 13 05:02:15 BST 2017
lib/features/com.ibm.websphere.appserver.json-1.0.mf=3c05e1a6bffad85bbd4f3e327398891d
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.json_1.0-javadoc.zip=58cb87efbbb282c9367053f9672c1821
dev/api/ibm/com.ibm.websphere.appserver.api.json_1.0.18.jar=e05268df6ff48c135c226ccd2d45ed6f
lib/com.ibm.json4j_1.0.18.jar=3fbef877a9ed344309c9c62c1f4f138a
