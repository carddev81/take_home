#Fri Oct 13 05:02:16 BST 2017
lib/features/com.ibm.ws.transaction.management.nls-1.0.mf=59e74fb81f48c67d86f14c54bd3119d2
lib/com.ibm.ws.transaction.management.nls_1.0.18.jar=497c3ad6b3a5c8518fc98c1ef7a62232
