#Fri Oct 13 05:02:16 BST 2017
lib/com.ibm.ws.messaging.jms.2.0.nls_1.0.18.jar=5a8fa8d7e52ac5bda588e44a267279b9
lib/features/com.ibm.ws.messaging.jms.2.0.nls-1.0.mf=132d1775932131c75db14dafe60e6dcf
