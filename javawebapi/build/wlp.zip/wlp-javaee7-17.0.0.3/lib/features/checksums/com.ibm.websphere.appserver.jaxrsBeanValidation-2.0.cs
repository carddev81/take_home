#Fri Oct 13 05:02:15 BST 2017
lib/com.ibm.ws.jaxrs.2.0.beanvalidation_1.0.18.jar=b14c3199078a62ad9a8e7818c2af895a
lib/features/com.ibm.websphere.appserver.jaxrsBeanValidation-2.0.mf=c031a11a4226feebd423ace2a9039a24
